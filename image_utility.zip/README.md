# Image Utility v2 — setup

A redesigned, photo-editor-style rebuild of the original four-tab app.

## Easiest: double-click `Run.bat`

Put `image_utility_v2.py` and `Run.bat` in the same folder, then
double-click `Run.bat`. The first time you launch:

1. A small dialog asks if it can install the packages it needs.
2. Click **Yes** — it shows live install progress.
3. The main app opens once setup finishes.

Subsequent launches go straight to the app.

If you'd rather use the command line:

```
python image_utility_v2.py
```

Same behaviour — auto-installs missing packages on first run.

## Background removal

This is the only "heavy" feature, so its packages aren't installed up
front. The first time you click **Apply** on the Background removal
tool, you'll get a dialog: *"This tool needs the 'rembg' package
(~200 MB). Install it now?"* — say yes, watch progress, then it just
works.

## Manual install (if you prefer)

Main app:
```
pip install customtkinter pillow tkinterdnd2
```

Background removal:
```
pip install rembg onnxruntime
```

## Troubleshooting

**Double-clicking `image_utility_v2.py` does nothing / window flashes.**
Use `Run.bat` instead. The cause is usually that Windows is using a
different Python install for double-click than the one in your PATH.
`Run.bat` finds the right Python and uses `pythonw.exe` so there's no
console flash.

**"Python is not installed" message from `Run.bat`.**
Get Python from <https://www.python.org/downloads/>. During install
**tick the "Add Python to PATH" checkbox** — that's the step people
miss most often.

**The auto-installer fails.**
Open Command Prompt, go to the folder with the .py file, and run:
```
pip install customtkinter pillow tkinterdnd2
```
Then re-launch.

## Where files live

- Presets:  `~/.image_utility_v2/presets.json`
- Logs:     `~/.image_utility_v2/logs/session_*.log` (last 10 kept)

## Bundling to an .exe (optional)

```
pip install pyinstaller
pyinstaller --noconfirm --windowed --name ImageUtility ^
  --collect-all customtkinter --collect-all tkinterdnd2 ^
  image_utility_v2.py
```

Output goes to `dist/ImageUtility/`. The .exe + the `_internal` folder
must stay together (same rule as your existing build).
