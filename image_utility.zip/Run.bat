@echo off
REM Image Utility launcher.
REM Double-click this file to run the app.

setlocal
cd /d "%~dp0"

REM Prefer the Python Launcher (py.exe) — it handles multiple installs well.
where /q py
if %errorlevel% == 0 (
    REM Use pythonw via py launcher so no console window stays open.
    start "" pyw image_utility_v2.py
    goto :end
)

REM Fall back to pythonw on PATH.
where /q pythonw
if %errorlevel% == 0 (
    start "" pythonw image_utility_v2.py
    goto :end
)

REM Last resort: plain python with a console (will pause on error so you can read it).
where /q python
if %errorlevel% == 0 (
    python image_utility_v2.py
    if errorlevel 1 (
        echo.
        echo Image Utility exited with an error.
        pause
    )
    goto :end
)

REM No Python at all.
echo.
echo Python is not installed, or it's not on your PATH.
echo.
echo Install Python from:  https://www.python.org/downloads/
echo.
echo IMPORTANT: during install, tick "Add Python to PATH".
echo.
pause

:end
endlocal
