"""
Image Utility v2 — redesigned interface

A photo-editor-style rebuild of the original four-tab app.

Run it
------
    python image_utility_v2.py

The first time you start it, any missing packages are installed for you
through a small dialog — no need to run `pip install` by hand. You can
also just double-click `Run.bat`.
"""

from __future__ import annotations

# ---------------------------------------------------------------------------
# Bootstrap — check required dependencies before importing them.
# This runs FIRST, using only Python's standard library, so the script
# can offer to install missing packages even on a clean machine.
# ---------------------------------------------------------------------------

import importlib
import subprocess
import sys
import threading
import traceback

# (import_name, pip_name) — split because they sometimes differ (PIL vs pillow)
_REQUIRED_PACKAGES = [
    ("customtkinter", "customtkinter"),
    ("PIL", "pillow"),
    ("tkinterdnd2", "tkinterdnd2"),
]


def _find_missing(packages):
    missing = []
    for module_name, pip_name in packages:
        try:
            importlib.import_module(module_name)
        except ImportError:
            missing.append(pip_name)
    return missing


def _bootstrap_install_required():
    """Called at startup. If any required package is missing, prompt and install."""
    missing = _find_missing(_REQUIRED_PACKAGES)
    if not missing:
        return True

    import tkinter as tk
    from tkinter import ttk, messagebox

    # 1) Ask permission
    ask = tk.Tk()
    ask.withdraw()
    msg = ("Image Utility needs to install a few packages before it can start:"
           "\n\n" + "\n".join("  • " + p for p in missing) +
           "\n\nThis will run:\n"
           "  pip install " + " ".join(missing) +
           "\n\nInstall now?")
    ok = messagebox.askyesno("Image Utility — First run", msg, parent=ask)
    ask.destroy()
    if not ok:
        sys.exit(0)

    # 2) Build install window
    win = tk.Tk()
    win.title("Image Utility — Setup")
    win.geometry("540x360")
    win.configure(bg="#14110f")
    win.update_idletasks()
    x = (win.winfo_screenwidth() - 540) // 2
    y = (win.winfo_screenheight() - 360) // 2
    win.geometry(f"540x360+{x}+{y}")

    header = tk.Frame(win, bg="#14110f")
    header.pack(fill="x", padx=24, pady=(20, 8))
    tk.Label(header, text="◐ Image Utility", bg="#14110f",
             fg="#d85a30", font=("Segoe UI", 14, "bold")).pack(side="left")
    tk.Label(header, text="First-time setup", bg="#14110f",
             fg="#8a8278", font=("Segoe UI", 10)).pack(side="right")

    tk.Label(win, text="Installing required packages…",
             bg="#14110f", fg="#ece6da",
             font=("Segoe UI", 11), anchor="w"
             ).pack(fill="x", padx=24)
    tk.Label(win, text=", ".join(missing),
             bg="#14110f", fg="#8a8278",
             font=("Segoe UI", 10), anchor="w"
             ).pack(fill="x", padx=24, pady=(0, 12))

    pb = ttk.Progressbar(win, length=480, mode="indeterminate")
    pb.pack(pady=4, padx=24)
    pb.start(12)

    log_box = tk.Text(win, height=10, bg="#1c1815", fg="#8a8278",
                      font=("Consolas", 9), borderwidth=0,
                      highlightthickness=1, highlightcolor="#312a23",
                      highlightbackground="#312a23")
    log_box.pack(fill="both", expand=True, padx=24, pady=12)

    status_lbl = tk.Label(win, text="Starting…", bg="#14110f",
                          fg="#8a8278", font=("Segoe UI", 10), anchor="w")
    status_lbl.pack(fill="x", padx=24, pady=(0, 14))

    result = {"success": False}

    def append(line):
        try:
            log_box.insert("end", line + "\n")
            log_box.see("end")
            if line.strip():
                status_lbl.config(text=line.strip()[:80])
        except tk.TclError:
            pass

    def run_pip():
        try:
            cmd = [sys.executable, "-m", "pip", "install",
                   "--disable-pip-version-check"] + list(missing)
            proc = subprocess.Popen(
                cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, bufsize=1, encoding="utf-8", errors="replace")
            assert proc.stdout is not None
            for line in iter(proc.stdout.readline, ""):
                if not line:
                    break
                win.after(0, lambda L=line.rstrip(): append(L))
            proc.wait()
            result["success"] = (proc.returncode == 0)
        except Exception as e:
            win.after(0, lambda: append(f"ERROR: {e}"))
        finally:
            def finish():
                try:
                    pb.stop()
                except Exception:
                    pass
                if result["success"]:
                    status_lbl.config(text="All packages installed.",
                                      fg="#7fa843")
                    win.after(900, win.destroy)
                else:
                    status_lbl.config(text="Installation failed — see log.",
                                      fg="#c4574e")
                    tk.Button(win, text="Close", command=win.destroy,
                              bg="#252019", fg="#ece6da",
                              activebackground="#312a23",
                              activeforeground="#ece6da",
                              borderwidth=0, padx=20, pady=6,
                              font=("Segoe UI", 10)).pack(pady=(0, 14))
            win.after(0, finish)

    threading.Thread(target=run_pip, daemon=True).start()
    win.mainloop()

    if not result["success"]:
        try:
            r = tk.Tk(); r.withdraw()
            messagebox.showerror(
                "Image Utility",
                "Setup failed.\n\nPlease open Command Prompt and run:\n\n"
                "  pip install " + " ".join(missing))
            r.destroy()
        except Exception:
            pass
        sys.exit(1)
    return True


_bootstrap_install_required()


# ---------------------------------------------------------------------------
# Normal imports — all packages are guaranteed available below this line.
# ---------------------------------------------------------------------------

import json
import os
import re
import time
from dataclasses import dataclass, field, asdict
from pathlib import Path
from queue import Queue
from tkinter import filedialog, messagebox
from typing import Any, Callable

import customtkinter as ctk
from PIL import Image, ImageDraw, ImageEnhance, ImageFont, ImageOps

# Drag-and-drop is optional — the app degrades gracefully without it.
try:
    from tkinterdnd2 import DND_FILES, TkinterDnD
    DND_AVAILABLE = True
except ImportError:
    DND_AVAILABLE = False

# rembg is heavy; only import on demand inside the BG tool
REMBG = None


def install_packages_in_app(app, packages: list[str], purpose: str = "") -> bool:
    """Install packages from inside the running app, with a modal CTkToplevel.
    Blocks until done. Returns True on success.

    Unlike the bootstrap version (which uses bare Tk), this uses CTk widgets
    so it matches the app's theme. Used for optional packages like rembg that
    we don't install until they're actually needed."""
    win = ctk.CTkToplevel(app)
    win.title("Installing")
    win.geometry("540x360")
    win.configure(fg_color="#14110f")
    win.transient(app)
    win.grab_set()
    win.resizable(False, False)

    # Centre relative to parent
    app.update_idletasks()
    px, py = app.winfo_x(), app.winfo_y()
    pw, ph = app.winfo_width(), app.winfo_height()
    win.geometry(f"540x360+{px + (pw - 540) // 2}+{py + (ph - 360) // 2}")

    header = ctk.CTkFrame(win, fg_color="transparent")
    header.pack(fill="x", padx=24, pady=(20, 4))
    ctk.CTkLabel(header, text=f"Installing: {purpose}" if purpose else "Installing",
                 text_color="#ece6da",
                 font=("Segoe UI", 13, "bold")).pack(side="left")

    ctk.CTkLabel(win, text=", ".join(packages),
                 text_color="#8a8278",
                 font=("Segoe UI", 10), anchor="w"
                 ).pack(fill="x", padx=24, pady=(0, 12))

    pb = ctk.CTkProgressBar(win, mode="indeterminate",
                            fg_color="#312a23", progress_color="#d85a30",
                            height=8)
    pb.pack(fill="x", padx=24)
    pb.start()

    log_box = ctk.CTkTextbox(win, fg_color="#1c1815", text_color="#8a8278",
                              font=("Consolas", 9), border_width=1,
                              border_color="#312a23")
    log_box.pack(fill="both", expand=True, padx=24, pady=12)

    status_lbl = ctk.CTkLabel(win, text="Starting pip…",
                              text_color="#8a8278",
                              font=("Segoe UI", 10), anchor="w")
    status_lbl.pack(fill="x", padx=24, pady=(0, 14))

    result = {"success": False}

    def append(line):
        try:
            log_box.insert("end", line + "\n")
            log_box.see("end")
            if line.strip():
                status_lbl.configure(text=line.strip()[:80])
        except Exception:
            pass

    def run_pip():
        try:
            cmd = [sys.executable, "-m", "pip", "install",
                   "--disable-pip-version-check"] + list(packages)
            proc = subprocess.Popen(
                cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, bufsize=1, encoding="utf-8", errors="replace")
            assert proc.stdout is not None
            for line in iter(proc.stdout.readline, ""):
                if not line:
                    break
                app.after(0, lambda L=line.rstrip(): append(L))
            proc.wait()
            result["success"] = (proc.returncode == 0)
        except Exception as e:
            app.after(0, lambda: append(f"ERROR: {e}"))
        finally:
            def finish():
                try:
                    pb.stop()
                except Exception:
                    pass
                if result["success"]:
                    status_lbl.configure(text="All packages installed.",
                                          text_color="#7fa843")
                    win.after(900, win.destroy)
                else:
                    status_lbl.configure(text="Installation failed — see log.",
                                          text_color="#c4574e")
                    ctk.CTkButton(win, text="Close", command=win.destroy,
                                  fg_color="#252019",
                                  hover_color="#312a23",
                                  text_color="#ece6da",
                                  font=("Segoe UI", 10),
                                  width=120, height=30
                                  ).pack(pady=(0, 14))
            app.after(0, finish)

    threading.Thread(target=run_pip, daemon=True).start()
    win.wait_window()  # block until dialog destroyed
    return result["success"]


# ---------------------------------------------------------------------------
# Theme — "Darkroom" palette
# ---------------------------------------------------------------------------

class Theme:
    """Warm-charcoal palette inspired by photographic darkrooms."""
    BG          = "#14110f"   # deepest surface
    SURFACE     = "#1c1815"   # panels
    SURFACE_2   = "#252019"   # raised elements
    BORDER      = "#312a23"
    BORDER_HI   = "#473d33"

    TEXT        = "#ece6da"   # warm off-white
    TEXT_MUTED  = "#8a8278"
    TEXT_DIM    = "#5b554d"

    ACCENT      = "#d85a30"   # safelight coral — primary action
    ACCENT_HI   = "#e87144"
    ACCENT_LO   = "#993c1d"
    ACCENT_SOFT = "#3a1f15"   # accent tinted into surface

    SUCCESS     = "#7fa843"
    WARNING     = "#c98a3a"
    DANGER      = "#c4574e"

    FONT        = "Segoe UI"
    FONT_MONO   = "Consolas"

    R_SM = 6
    R_MD = 8
    R_LG = 12


ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")  # we override per-widget anyway


# ---------------------------------------------------------------------------
# App state
# ---------------------------------------------------------------------------

SUPPORTED_EXTS = {".png", ".jpg", ".jpeg", ".webp", ".bmp", ".tif", ".tiff"}
APP_DIR = Path.home() / ".image_utility_v2"
APP_DIR.mkdir(exist_ok=True)
PRESETS_FILE = APP_DIR / "presets.json"
LOGS_DIR = APP_DIR / "logs"
LOGS_DIR.mkdir(exist_ok=True)


@dataclass
class QueueItem:
    tool_id: str
    tool_name: str
    settings: dict
    label: str = ""

    def display(self) -> str:
        return self.label or self.tool_name


@dataclass
class AppState:
    """Global, observable application state."""
    image_path: Path | None = None
    image: Image.Image | None = None       # current working image
    original: Image.Image | None = None    # before any in-session edits
    last_preview: Image.Image | None = None  # output of last op (for before/after)

    undo_stack: list[Image.Image] = field(default_factory=list)
    redo_stack: list[Image.Image] = field(default_factory=list)
    max_undo: int = 25

    presets: dict[str, dict] = field(default_factory=dict)  # name -> {tool_id, settings}
    queue: list[QueueItem] = field(default_factory=list)

    active_tool: str = "bg_removal"

    listeners: list[Callable[[str], None]] = field(default_factory=list)
    _tk_root: Any = None  # set by App for thread-safe UI updates

    def notify(self, event: str = "change") -> None:
        # If called from a worker thread, marshal back to the main thread.
        # Tk widgets must only be touched from the thread that created them.
        def fire():
            for fn in list(self.listeners):
                try:
                    fn(event)
                except Exception:
                    traceback.print_exc()
        if self._tk_root is not None:
            try:
                self._tk_root.after(0, fire)
                return
            except Exception:
                pass
        fire()

    # ---- image lifecycle ----

    def load_image(self, path: Path) -> None:
        img = Image.open(path)
        img.load()
        if img.mode not in ("RGB", "RGBA"):
            img = img.convert("RGBA" if "A" in img.getbands() else "RGB")
        self.image_path = path
        self.original = img.copy()
        self.image = img
        self.last_preview = None
        self.undo_stack.clear()
        self.redo_stack.clear()
        self.notify("image_loaded")

    def commit(self, new_image: Image.Image) -> None:
        """Replace current image, pushing previous to undo stack."""
        if self.image is not None:
            self.undo_stack.append(self.image)
            if len(self.undo_stack) > self.max_undo:
                self.undo_stack.pop(0)
        self.redo_stack.clear()
        self.last_preview = self.image  # the "before" half of the slider
        self.image = new_image
        self.notify("image_changed")

    def undo(self) -> bool:
        if not self.undo_stack:
            return False
        self.redo_stack.append(self.image)
        self.image = self.undo_stack.pop()
        self.notify("image_changed")
        return True

    def redo(self) -> bool:
        if not self.redo_stack:
            return False
        self.undo_stack.append(self.image)
        self.image = self.redo_stack.pop()
        self.notify("image_changed")
        return True

    # ---- presets ----

    def load_presets(self) -> None:
        if PRESETS_FILE.exists():
            try:
                self.presets = json.loads(PRESETS_FILE.read_text(encoding="utf-8"))
            except Exception:
                self.presets = {}

    def save_presets(self) -> None:
        PRESETS_FILE.write_text(json.dumps(self.presets, indent=2), encoding="utf-8")


# ---------------------------------------------------------------------------
# Logging — writes to file and to an in-app buffer
# ---------------------------------------------------------------------------

class Log:
    def __init__(self) -> None:
        ts = time.strftime("%Y%m%d_%H%M%S")
        self.path = LOGS_DIR / f"session_{ts}.log"
        self.lines: list[tuple[str, str]] = []  # (level, message)
        self.listeners: list[Callable[[str, str], None]] = []
        self.tk_root: Any = None
        self._trim_old_logs()

    def _trim_old_logs(self) -> None:
        files = sorted(LOGS_DIR.glob("session_*.log"))
        for f in files[:-10]:
            try:
                f.unlink()
            except OSError:
                pass

    def _write(self, level: str, msg: str) -> None:
        stamp = time.strftime("%H:%M:%S")
        line = f"[{stamp}] {level:<7} {msg}"
        self.lines.append((level, line))
        try:
            with self.path.open("a", encoding="utf-8") as f:
                f.write(line + "\n")
        except OSError:
            pass
        def fire():
            for fn in self.listeners:
                try:
                    fn(level, line)
                except Exception:
                    pass
        if self.tk_root is not None:
            try:
                self.tk_root.after(0, fire)
                return
            except Exception:
                pass
        fire()

    def info(self, msg: str) -> None:    self._write("INFO", msg)
    def warn(self, msg: str) -> None:    self._write("WARNING", msg)
    def error(self, msg: str) -> None:   self._write("ERROR", msg)
    def debug(self, msg: str) -> None:   self._write("DEBUG", msg)


log = Log()


# ---------------------------------------------------------------------------
# Tool base class — every tool plugs in via this contract
# ---------------------------------------------------------------------------

class Tool:
    tool_id: str = ""
    name: str = ""
    icon: str = "•"       # single glyph for the rail
    description: str = ""
    supports_apply: bool = True   # show the footer "Apply" button?
    is_slow: bool = False         # show a progress overlay during run_single?

    def __init__(self, app: "ImageUtilityApp") -> None:
        self.app = app
        self.state = app.app_state

    def build_panel(self, parent: ctk.CTkFrame) -> None:
        """Render the right-side property panel into `parent`."""
        raise NotImplementedError

    def get_settings(self) -> dict:
        """Snapshot current panel values (for presets and queue)."""
        return {}

    def apply_settings(self, settings: dict) -> None:
        """Restore from a preset/queue snapshot."""
        pass

    def can_run(self) -> bool:
        return self.state.image is not None

    def run_single(self) -> None:
        """Run on the current image, committing the result via state.commit()."""
        pass

    def output_extension(self) -> str | None:
        """Optional: override the output file extension when this tool runs in a queue.
        Return '.png', '.jpg', '.webp', or None to keep the input extension."""
        return None

    def output_save_kwargs(self) -> dict:
        """Optional: extra PIL save kwargs (e.g. {'quality': 80}) for queue output."""
        return {}

    def run_batch(self, input_dir: Path, output_dir: Path,
                  progress: Callable[[int, int, str], None]) -> int:
        """Run on every supported image in input_dir. Return count processed."""
        return 0


# ---------------------------------------------------------------------------
# Reusable panel helpers
# ---------------------------------------------------------------------------

def label(parent, text: str, **kw) -> ctk.CTkLabel:
    return ctk.CTkLabel(parent, text=text, text_color=Theme.TEXT_MUTED,
                        font=(Theme.FONT, 11), anchor="w", **kw)

def section(parent, text: str) -> ctk.CTkLabel:
    return ctk.CTkLabel(parent, text=text.upper(), text_color=Theme.TEXT_DIM,
                        font=(Theme.FONT, 10, "bold"), anchor="w")

def hint(parent, text: str) -> ctk.CTkLabel:
    f = ctk.CTkFrame(parent, fg_color=Theme.SURFACE_2, corner_radius=Theme.R_SM)
    inner = ctk.CTkLabel(f, text=text, text_color=Theme.TEXT_MUTED,
                         font=(Theme.FONT, 10), justify="left",
                         wraplength=220, anchor="w")
    inner.pack(padx=10, pady=8, fill="x")
    return f

def slider_row(parent, label_text: str, from_: float, to: float,
               default: float, on_change=None, fmt: str = "{:.0f}"):
    """Returns a dict with .frame, .slider, .value_var, .get()/.set()."""
    frame = ctk.CTkFrame(parent, fg_color="transparent")
    top = ctk.CTkFrame(frame, fg_color="transparent")
    top.pack(fill="x")
    label(top, label_text).pack(side="left")
    value_lbl = ctk.CTkLabel(top, text=fmt.format(default),
                             text_color=Theme.TEXT, font=(Theme.FONT, 11, "bold"))
    value_lbl.pack(side="right")
    var = ctk.DoubleVar(value=default)

    def _on(v):
        try:
            value_lbl.configure(text=fmt.format(float(v)))
        except Exception:
            pass
        if on_change:
            on_change(float(v))

    slider = ctk.CTkSlider(frame, from_=from_, to=to, variable=var, command=_on,
                           button_color=Theme.ACCENT, button_hover_color=Theme.ACCENT_HI,
                           progress_color=Theme.ACCENT_LO, fg_color=Theme.BORDER,
                           height=14)
    slider.pack(fill="x", pady=(4, 0))
    return {"frame": frame, "slider": slider, "var": var, "label": value_lbl,
            "get": lambda: var.get(), "set": lambda v: (var.set(v), _on(v))}


def primary_button(parent, text: str, command=None, icon: str = "") -> ctk.CTkButton:
    return ctk.CTkButton(parent, text=f"{icon}  {text}" if icon else text,
                         command=command, fg_color=Theme.ACCENT,
                         hover_color=Theme.ACCENT_HI, text_color="#ffffff",
                         font=(Theme.FONT, 12, "bold"), height=36,
                         corner_radius=Theme.R_MD)


def ghost_button(parent, text: str, command=None) -> ctk.CTkButton:
    return ctk.CTkButton(parent, text=text, command=command,
                         fg_color="transparent", hover_color=Theme.SURFACE_2,
                         text_color=Theme.TEXT_MUTED, border_width=1,
                         border_color=Theme.BORDER, font=(Theme.FONT, 11),
                         height=28, corner_radius=Theme.R_SM)


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------

class BgRemovalTool(Tool):
    tool_id = "bg_removal"
    name = "Background removal"
    icon = "◐"
    description = "Cut subjects out of photos"
    is_slow = True

    MODELS = ["u2net", "isnet-general-use", "birefnet-general"]

    def __init__(self, app):
        super().__init__(app)
        self.model_var = ctk.StringVar(value="u2net")
        self.alpha_matting = ctk.BooleanVar(value=False)
        self.feather = ctk.IntVar(value=0)

    def build_panel(self, parent):
        section(parent, "Model").pack(fill="x", pady=(0, 4))
        ctk.CTkOptionMenu(parent, values=self.MODELS, variable=self.model_var,
                          fg_color=Theme.SURFACE_2, button_color=Theme.BORDER,
                          button_hover_color=Theme.BORDER_HI,
                          text_color=Theme.TEXT,
                          font=(Theme.FONT, 11)).pack(fill="x", pady=(0, 12))

        ctk.CTkCheckBox(parent, text="Alpha matting (fuzzy edges)",
                        variable=self.alpha_matting, text_color=Theme.TEXT,
                        fg_color=Theme.ACCENT, hover_color=Theme.ACCENT_HI,
                        border_color=Theme.BORDER_HI,
                        font=(Theme.FONT, 11)).pack(anchor="w", pady=(0, 12))

        slider_row(parent, "Edge feather", 0, 20,
                   self.feather.get(),
                   on_change=lambda v: self.feather.set(int(v)),
                   fmt="{:.0f} px")["frame"].pack(fill="x", pady=(0, 12))

        hint(parent, "Alpha matting helps with hair and fur edges but is slower. "
                     "Requires the rembg package.").pack(fill="x", pady=(0, 12))

    def get_settings(self):
        return {"model": self.model_var.get(),
                "alpha_matting": bool(self.alpha_matting.get()),
                "feather": int(self.feather.get())}

    def apply_settings(self, settings):
        self.model_var.set(settings.get("model", "u2net"))
        self.alpha_matting.set(settings.get("alpha_matting", False))
        self.feather.set(settings.get("feather", 0))

    def _load_rembg(self):
        global REMBG
        if REMBG is not None:
            return REMBG
        try:
            from rembg import remove, new_session
            REMBG = {"remove": remove, "new_session": new_session,
                     "_sessions": {}}
            return REMBG
        except ImportError:
            pass  # fall through to install offer

        # Offer to install. The download is ~200 MB (onnxruntime is the bulk).
        ok = messagebox.askyesno(
            "Background removal",
            "This tool needs the 'rembg' package, which isn't installed.\n\n"
            "Install it now?  (~200 MB, one-time download)\n\n"
            "This will run:\n"
            "  pip install rembg onnxruntime")
        if not ok:
            raise RuntimeError("rembg is required for background removal")

        success = install_packages_in_app(
            self.app, ["rembg", "onnxruntime"],
            purpose="Background removal")
        if not success:
            raise RuntimeError(
                "Installation failed. Try running this in Command Prompt:\n"
                "  pip install rembg onnxruntime")

        # Try import again — the install put it on disk during this same process,
        # so it should now succeed without restarting the app.
        try:
            from rembg import remove, new_session
            REMBG = {"remove": remove, "new_session": new_session,
                     "_sessions": {}}
            log.info("rembg installed and loaded")
            return REMBG
        except ImportError as e:
            raise RuntimeError(
                "rembg installed but couldn't be imported. "
                "Please restart Image Utility.") from e

    def _process(self, img: Image.Image) -> Image.Image:
        rembg = self._load_rembg()
        sess_key = self.model_var.get()
        if sess_key not in rembg["_sessions"]:
            rembg["_sessions"][sess_key] = rembg["new_session"](sess_key)
        result = rembg["remove"](img, session=rembg["_sessions"][sess_key],
                                 alpha_matting=bool(self.alpha_matting.get()))
        feather = int(self.feather.get())
        if feather > 0 and result.mode == "RGBA":
            from PIL import ImageFilter
            r, g, b, a = result.split()
            a = a.filter(ImageFilter.GaussianBlur(radius=feather))
            result = Image.merge("RGBA", (r, g, b, a))
        return result

    def run_single(self):
        if not self.can_run():
            return
        try:
            out = self._process(self.state.image)
            self.state.commit(out)
            log.info(f"Background removed using {self.model_var.get()}")
        except Exception as e:
            log.error(f"BG removal failed: {e}")
            messagebox.showerror("Background removal", str(e))


class ResizeConvertTool(Tool):
    tool_id = "resize_convert"
    name = "Resize & convert"
    icon = "⇲"
    description = "Resize, compress, change format"

    def __init__(self, app):
        super().__init__(app)
        self.mode = ctk.StringVar(value="Longest side")
        self.value = ctk.IntVar(value=1920)
        self.format = ctk.StringVar(value="Keep")
        self.quality = ctk.IntVar(value=88)
        self.keep_aspect = ctk.BooleanVar(value=True)

    def build_panel(self, parent):
        section(parent, "Resize").pack(fill="x", pady=(0, 4))
        ctk.CTkOptionMenu(parent,
                          values=["Longest side", "Width", "Height", "Percentage", "Exact"],
                          variable=self.mode,
                          fg_color=Theme.SURFACE_2, button_color=Theme.BORDER,
                          button_hover_color=Theme.BORDER_HI,
                          text_color=Theme.TEXT,
                          font=(Theme.FONT, 11)).pack(fill="x", pady=(0, 8))

        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", pady=(0, 12))
        label(row, "Pixels").pack(side="left")
        ctk.CTkEntry(row, textvariable=self.value, width=80,
                     fg_color=Theme.SURFACE_2, border_color=Theme.BORDER,
                     text_color=Theme.TEXT, font=(Theme.FONT, 11)).pack(side="right")

        section(parent, "Output").pack(fill="x", pady=(0, 4))
        ctk.CTkOptionMenu(parent, values=["Keep", "PNG", "JPG", "WEBP"],
                          variable=self.format,
                          fg_color=Theme.SURFACE_2, button_color=Theme.BORDER,
                          button_hover_color=Theme.BORDER_HI,
                          text_color=Theme.TEXT,
                          font=(Theme.FONT, 11)).pack(fill="x", pady=(0, 8))

        slider_row(parent, "Quality (JPG/WEBP)", 30, 100,
                   self.quality.get(),
                   on_change=lambda v: self.quality.set(int(v)),
                   fmt="{:.0f}")["frame"].pack(fill="x", pady=(0, 12))

    def get_settings(self):
        return {"mode": self.mode.get(), "value": int(self.value.get()),
                "format": self.format.get(), "quality": int(self.quality.get())}

    def apply_settings(self, s):
        self.mode.set(s.get("mode", "Longest side"))
        self.value.set(s.get("value", 1920))
        self.format.set(s.get("format", "Keep"))
        self.quality.set(s.get("quality", 88))

    def _compute_size(self, img: Image.Image) -> tuple[int, int]:
        w, h = img.size
        m = self.mode.get()
        v = int(self.value.get())
        if m == "Longest side":
            scale = v / max(w, h)
        elif m == "Width":
            scale = v / w
        elif m == "Height":
            scale = v / h
        elif m == "Percentage":
            scale = v / 100.0
        elif m == "Exact":
            return v, v
        else:
            scale = 1.0
        return max(1, int(w * scale)), max(1, int(h * scale))

    def run_single(self):
        if not self.can_run():
            return
        new_size = self._compute_size(self.state.image)
        out = self.state.image.resize(new_size, Image.LANCZOS)
        self.state.commit(out)
        log.info(f"Resized to {new_size[0]}x{new_size[1]}")

    def output_extension(self) -> str | None:
        fmt = self.format.get()
        return {"PNG": ".png", "JPG": ".jpg", "WEBP": ".webp"}.get(fmt)

    def output_save_kwargs(self) -> dict:
        fmt = self.format.get()
        if fmt in ("JPG", "WEBP"):
            return {"quality": int(self.quality.get())}
        return {}


class CropRotateTool(Tool):
    tool_id = "crop_rotate"
    name = "Crop & rotate"
    icon = "⊟"

    def __init__(self, app):
        super().__init__(app)
        self.rotation = ctk.IntVar(value=0)
        self.flip_h = ctk.BooleanVar(value=False)
        self.flip_v = ctk.BooleanVar(value=False)
        self.aspect = ctk.StringVar(value="Free")

    def build_panel(self, parent):
        section(parent, "Rotation").pack(fill="x", pady=(0, 4))
        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", pady=(0, 12))
        for deg in (90, 180, 270):
            ctk.CTkButton(row, text=f"{deg}°", width=50, height=28,
                          fg_color=Theme.SURFACE_2, hover_color=Theme.BORDER_HI,
                          text_color=Theme.TEXT, font=(Theme.FONT, 11),
                          corner_radius=Theme.R_SM,
                          command=lambda d=deg: self._rotate(d)).pack(side="left", padx=2)

        ctk.CTkCheckBox(parent, text="Flip horizontal", variable=self.flip_h,
                        text_color=Theme.TEXT, fg_color=Theme.ACCENT,
                        border_color=Theme.BORDER_HI,
                        font=(Theme.FONT, 11)).pack(anchor="w", pady=2)
        ctk.CTkCheckBox(parent, text="Flip vertical", variable=self.flip_v,
                        text_color=Theme.TEXT, fg_color=Theme.ACCENT,
                        border_color=Theme.BORDER_HI,
                        font=(Theme.FONT, 11)).pack(anchor="w", pady=(2, 12))

        section(parent, "Aspect crop").pack(fill="x", pady=(0, 4))
        ctk.CTkOptionMenu(parent, values=["Free", "1:1 Square", "4:5 Portrait",
                                          "16:9 Wide", "9:16 Story"],
                          variable=self.aspect,
                          fg_color=Theme.SURFACE_2, button_color=Theme.BORDER,
                          button_hover_color=Theme.BORDER_HI,
                          text_color=Theme.TEXT,
                          font=(Theme.FONT, 11)).pack(fill="x", pady=(0, 8))

        ghost_button(parent, "Crop to aspect", command=self._crop_aspect)\
            .pack(fill="x", pady=(0, 12))

        hint(parent, "For free-hand crop, drag a selection on the canvas "
                     "(coming in interactive build).").pack(fill="x")

    def _rotate(self, degrees: int):
        if not self.can_run():
            return
        out = self.state.image.rotate(-degrees, expand=True)
        self.state.commit(out)
        log.info(f"Rotated {degrees}°")

    def _crop_aspect(self):
        if not self.can_run():
            return
        ratios = {"1:1 Square": (1, 1), "4:5 Portrait": (4, 5),
                  "16:9 Wide": (16, 9), "9:16 Story": (9, 16)}
        if self.aspect.get() == "Free":
            return
        rw, rh = ratios[self.aspect.get()]
        w, h = self.state.image.size
        target_ratio = rw / rh
        cur_ratio = w / h
        if cur_ratio > target_ratio:
            new_w = int(h * target_ratio); new_h = h
        else:
            new_w = w; new_h = int(w / target_ratio)
        left = (w - new_w) // 2; top = (h - new_h) // 2
        out = self.state.image.crop((left, top, left + new_w, top + new_h))
        self.state.commit(out)
        log.info(f"Cropped to {self.aspect.get()} ({new_w}x{new_h})")

    def run_single(self):
        if not self.can_run():
            return
        img = self.state.image
        if self.flip_h.get():
            img = ImageOps.mirror(img)
        if self.flip_v.get():
            img = ImageOps.flip(img)
        self.state.commit(img)

    def get_settings(self):
        return {"aspect": self.aspect.get(), "flip_h": bool(self.flip_h.get()),
                "flip_v": bool(self.flip_v.get())}

    def apply_settings(self, s):
        self.aspect.set(s.get("aspect", "Free"))
        self.flip_h.set(s.get("flip_h", False))
        self.flip_v.set(s.get("flip_v", False))


class ColorAdjustTool(Tool):
    tool_id = "color_adjust"
    name = "Color adjust"
    icon = "◑"

    def __init__(self, app):
        super().__init__(app)
        self.brightness = 1.0
        self.contrast = 1.0
        self.saturation = 1.0
        self.warmth = 0  # -50..50

    def build_panel(self, parent):
        for name, attr, lo, hi, default, fmt in [
            ("Brightness", "brightness", 0.3, 2.0, 1.0, "{:.2f}"),
            ("Contrast",   "contrast",   0.3, 2.0, 1.0, "{:.2f}"),
            ("Saturation", "saturation", 0.0, 2.0, 1.0, "{:.2f}"),
            ("Warmth",     "warmth",   -50,  50,   0,   "{:.0f}"),
        ]:
            slider_row(parent, name, lo, hi, default,
                       on_change=lambda v, a=attr: setattr(self, a, v),
                       fmt=fmt)["frame"].pack(fill="x", pady=(0, 10))

        ghost_button(parent, "Auto-enhance",
                     command=self._auto).pack(fill="x", pady=(8, 4))
        ghost_button(parent, "Reset",
                     command=self._reset).pack(fill="x")

    def _auto(self):
        if not self.can_run():
            return
        img = self.state.image
        if img.mode == "RGBA":
            r, g, b, a = img.split()
            rgb = Image.merge("RGB", (r, g, b))
            rgb = ImageOps.autocontrast(rgb)
            r, g, b = rgb.split()
            out = Image.merge("RGBA", (r, g, b, a))
        else:
            out = ImageOps.autocontrast(img.convert("RGB"))
        self.state.commit(out)
        log.info("Applied auto-contrast")

    def _reset(self):
        self.brightness = self.contrast = self.saturation = 1.0
        self.warmth = 0
        # Re-render panel by re-activating tool
        self.app.activate_tool(self.tool_id)

    def _apply_warmth(self, img: Image.Image, amount: int) -> Image.Image:
        if amount == 0:
            return img
        if img.mode == "RGBA":
            r, g, b, a = img.split()
        else:
            img = img.convert("RGB")
            r, g, b = img.split()
            a = None
        # Positive = warmer (more red, less blue)
        delta = amount / 50.0  # -1..1
        r = r.point(lambda v: max(0, min(255, v + delta * 30)))
        b = b.point(lambda v: max(0, min(255, v - delta * 30)))
        if a is not None:
            return Image.merge("RGBA", (r, g, b, a))
        return Image.merge("RGB", (r, g, b))

    def run_single(self):
        if not self.can_run():
            return
        img = self.state.image
        if self.brightness != 1.0:
            img = ImageEnhance.Brightness(img).enhance(self.brightness)
        if self.contrast != 1.0:
            img = ImageEnhance.Contrast(img).enhance(self.contrast)
        if self.saturation != 1.0:
            img = ImageEnhance.Color(img).enhance(self.saturation)
        if self.warmth != 0:
            img = self._apply_warmth(img, int(self.warmth))
        self.state.commit(img)
        log.info("Color adjustments applied")

    def get_settings(self):
        return {"brightness": self.brightness, "contrast": self.contrast,
                "saturation": self.saturation, "warmth": self.warmth}

    def apply_settings(self, s):
        self.brightness = s.get("brightness", 1.0)
        self.contrast = s.get("contrast", 1.0)
        self.saturation = s.get("saturation", 1.0)
        self.warmth = s.get("warmth", 0)


class WatermarkTool(Tool):
    tool_id = "watermark"
    name = "Watermark"
    icon = "©"

    POSITIONS = ["Bottom-right", "Bottom-left", "Top-right", "Top-left", "Center"]

    def __init__(self, app):
        super().__init__(app)
        self.text = ctk.StringVar(value="© Your Name")
        self.position = ctk.StringVar(value="Bottom-right")
        self.opacity = ctk.IntVar(value=70)
        self.size_pct = ctk.IntVar(value=4)  # font size as % of image min dim
        self.margin = ctk.IntVar(value=24)

    def build_panel(self, parent):
        section(parent, "Text").pack(fill="x", pady=(0, 4))
        ctk.CTkEntry(parent, textvariable=self.text,
                     fg_color=Theme.SURFACE_2, border_color=Theme.BORDER,
                     text_color=Theme.TEXT,
                     font=(Theme.FONT, 11)).pack(fill="x", pady=(0, 12))

        section(parent, "Position").pack(fill="x", pady=(0, 4))
        ctk.CTkOptionMenu(parent, values=self.POSITIONS, variable=self.position,
                          fg_color=Theme.SURFACE_2, button_color=Theme.BORDER,
                          button_hover_color=Theme.BORDER_HI,
                          text_color=Theme.TEXT,
                          font=(Theme.FONT, 11)).pack(fill="x", pady=(0, 12))

        slider_row(parent, "Opacity", 10, 100, self.opacity.get(),
                   on_change=lambda v: self.opacity.set(int(v)),
                   fmt="{:.0f}%")["frame"].pack(fill="x", pady=(0, 10))
        slider_row(parent, "Size", 2, 12, self.size_pct.get(),
                   on_change=lambda v: self.size_pct.set(int(v)),
                   fmt="{:.0f}%")["frame"].pack(fill="x", pady=(0, 10))
        slider_row(parent, "Margin", 0, 100, self.margin.get(),
                   on_change=lambda v: self.margin.set(int(v)),
                   fmt="{:.0f} px")["frame"].pack(fill="x", pady=(0, 12))

    def _get_font(self, size_px: int) -> ImageFont.ImageFont:
        for name in ("segoeui.ttf", "Arial.ttf", "DejaVuSans.ttf"):
            try:
                return ImageFont.truetype(name, size_px)
            except OSError:
                continue
        return ImageFont.load_default()

    def _apply(self, img: Image.Image) -> Image.Image:
        if img.mode != "RGBA":
            img = img.convert("RGBA")
        overlay = Image.new("RGBA", img.size, (0, 0, 0, 0))
        draw = ImageDraw.Draw(overlay)
        w, h = img.size
        size_px = max(12, int(min(w, h) * self.size_pct.get() / 100))
        font = self._get_font(size_px)
        text = self.text.get()
        bbox = draw.textbbox((0, 0), text, font=font)
        tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
        m = int(self.margin.get())
        positions = {
            "Bottom-right": (w - tw - m, h - th - m * 2),
            "Bottom-left":  (m, h - th - m * 2),
            "Top-right":    (w - tw - m, m),
            "Top-left":     (m, m),
            "Center":       ((w - tw) // 2, (h - th) // 2),
        }
        x, y = positions[self.position.get()]
        alpha = int(255 * self.opacity.get() / 100)
        # Subtle shadow for legibility
        draw.text((x + 2, y + 2), text, font=font, fill=(0, 0, 0, alpha // 2))
        draw.text((x, y), text, font=font, fill=(255, 255, 255, alpha))
        return Image.alpha_composite(img, overlay)

    def run_single(self):
        if not self.can_run():
            return
        self.state.commit(self._apply(self.state.image))
        log.info(f"Watermarked at {self.position.get()}")

    def get_settings(self):
        return {"text": self.text.get(), "position": self.position.get(),
                "opacity": int(self.opacity.get()),
                "size_pct": int(self.size_pct.get()),
                "margin": int(self.margin.get())}

    def apply_settings(self, s):
        self.text.set(s.get("text", "© Your Name"))
        self.position.set(s.get("position", "Bottom-right"))
        self.opacity.set(s.get("opacity", 70))
        self.size_pct.set(s.get("size_pct", 4))
        self.margin.set(s.get("margin", 24))


class BatchRenameTool(Tool):
    tool_id = "batch_rename"
    name = "Batch rename"
    icon = "Aa"
    supports_apply = False

    def __init__(self, app):
        super().__init__(app)
        self.pattern = ctk.StringVar(value="img_{n:03d}")
        self.start = ctk.IntVar(value=1)
        self.input_dir: Path | None = None

    def build_panel(self, parent):
        section(parent, "Pattern").pack(fill="x", pady=(0, 4))
        ctk.CTkEntry(parent, textvariable=self.pattern,
                     fg_color=Theme.SURFACE_2, border_color=Theme.BORDER,
                     text_color=Theme.TEXT,
                     font=(Theme.FONT, 11)).pack(fill="x", pady=(0, 8))

        hint(parent, "Tokens:  {n} number  ·  {name} original  ·  {ext} extension\n"
                     "Example:  product_{n:04d}").pack(fill="x", pady=(0, 12))

        section(parent, "Start at").pack(fill="x", pady=(0, 4))
        ctk.CTkEntry(parent, textvariable=self.start, width=80,
                     fg_color=Theme.SURFACE_2, border_color=Theme.BORDER,
                     text_color=Theme.TEXT,
                     font=(Theme.FONT, 11)).pack(anchor="w", pady=(0, 12))

        ghost_button(parent, "Choose folder…", command=self._choose)\
            .pack(fill="x", pady=(0, 4))
        primary_button(parent, "Rename folder", command=self._rename)\
            .pack(fill="x")

    def _choose(self):
        d = filedialog.askdirectory(title="Pick folder to rename")
        if d:
            self.input_dir = Path(d)
            log.info(f"Rename target: {d}")

    def _rename(self):
        if not self.input_dir:
            self._choose()
            if not self.input_dir:
                return
        files = sorted([p for p in self.input_dir.iterdir()
                        if p.suffix.lower() in SUPPORTED_EXTS])
        if not files:
            log.warn("No supported images in selected folder")
            return
        pat = self.pattern.get()
        n = int(self.start.get())
        # Two-pass to avoid collisions
        tmp_names = []
        for i, p in enumerate(files):
            new = pat.format(n=n + i, name=p.stem, ext=p.suffix.lstrip("."))
            tmp_names.append((p, p.with_name(f"__tmp_{i}_{p.name}"),
                              p.with_name(new + p.suffix)))
        try:
            for src, tmp, _ in tmp_names:
                src.rename(tmp)
            for _, tmp, dst in tmp_names:
                tmp.rename(dst)
            log.info(f"Renamed {len(tmp_names)} files")
            messagebox.showinfo("Batch rename",
                                f"Renamed {len(tmp_names)} files.")
        except Exception as e:
            log.error(f"Rename failed: {e}")
            messagebox.showerror("Batch rename", str(e))


class GridSplitTool(Tool):
    tool_id = "grid_split"
    name = "Grid split"
    icon = "⊞"
    supports_apply = False

    def __init__(self, app):
        super().__init__(app)
        self.rows = ctk.IntVar(value=2)
        self.cols = ctk.IntVar(value=3)

    def build_panel(self, parent):
        for label_text, var in [("Rows", self.rows), ("Cols", self.cols)]:
            row = ctk.CTkFrame(parent, fg_color="transparent")
            row.pack(fill="x", pady=4)
            label(row, label_text).pack(side="left")
            ctk.CTkEntry(row, textvariable=var, width=80,
                         fg_color=Theme.SURFACE_2, border_color=Theme.BORDER,
                         text_color=Theme.TEXT,
                         font=(Theme.FONT, 11)).pack(side="right")

        hint(parent, "Splits the current image into rows × cols cells. "
                     "Output as cell_<row>_<col>.png in the chosen folder.").pack(
            fill="x", pady=(8, 12))

        primary_button(parent, "Split and save…",
                       command=self._run).pack(fill="x")

    def _run(self):
        if not self.can_run():
            return
        out_dir = filedialog.askdirectory(title="Save cells to…")
        if not out_dir:
            return
        out_dir = Path(out_dir)
        r, c = int(self.rows.get()), int(self.cols.get())
        if r < 1 or c < 1:
            return
        w, h = self.state.image.size
        cw, ch = w // c, h // r
        count = 0
        for i in range(r):
            for j in range(c):
                box = (j * cw, i * ch, (j + 1) * cw, (i + 1) * ch)
                cell = self.state.image.crop(box)
                cell.save(out_dir / f"cell_{i}_{j}.png")
                count += 1
        log.info(f"Split into {count} cells in {out_dir}")
        messagebox.showinfo("Grid split",
                            f"Saved {count} cells to:\n{out_dir}")


class AtlasCreatorTool(Tool):
    tool_id = "atlas_creator"
    name = "Atlas creator"
    icon = "⊞⊞"
    supports_apply = False

    def __init__(self, app):
        super().__init__(app)
        self.rows = ctk.IntVar(value=4)
        self.cols = ctk.IntVar(value=4)
        self.padding = ctk.IntVar(value=0)
        self.input_dir: Path | None = None

    def build_panel(self, parent):
        for label_text, var in [("Rows", self.rows), ("Cols", self.cols),
                                ("Padding (px)", self.padding)]:
            row = ctk.CTkFrame(parent, fg_color="transparent")
            row.pack(fill="x", pady=4)
            label(row, label_text).pack(side="left")
            ctk.CTkEntry(row, textvariable=var, width=80,
                         fg_color=Theme.SURFACE_2, border_color=Theme.BORDER,
                         text_color=Theme.TEXT,
                         font=(Theme.FONT, 11)).pack(side="right")

        ghost_button(parent, "Choose input folder…",
                     command=self._choose).pack(fill="x", pady=(8, 4))
        primary_button(parent, "Build atlas",
                       command=self._build).pack(fill="x", pady=(4, 0))

    def _natural_key(self, p: Path):
        return [int(s) if s.isdigit() else s.lower()
                for s in re.split(r"(\d+)", p.name)]

    def _choose(self):
        d = filedialog.askdirectory(title="Pick folder of images")
        if d:
            self.input_dir = Path(d)
            log.info(f"Atlas input: {d}")

    def _build(self):
        if not self.input_dir:
            self._choose()
            if not self.input_dir:
                return
        files = sorted([p for p in self.input_dir.iterdir()
                        if p.suffix.lower() in SUPPORTED_EXTS],
                       key=self._natural_key)
        r, c = int(self.rows.get()), int(self.cols.get())
        pad = int(self.padding.get())
        needed = r * c
        if len(files) < needed:
            messagebox.showwarning("Atlas", f"Need {needed} images, found {len(files)}")
            return
        files = files[:needed]
        first = Image.open(files[0]); first.load()
        cw, ch = first.size
        atlas_w = cw * c + pad * (c - 1)
        atlas_h = ch * r + pad * (r - 1)
        atlas = Image.new("RGBA", (atlas_w, atlas_h), (0, 0, 0, 0))
        for idx, f in enumerate(files):
            img = Image.open(f); img.load()
            if img.size != (cw, ch):
                img = img.resize((cw, ch), Image.LANCZOS)
                log.warn(f"Resized {f.name} to match cell")
            row, col = idx // c, idx % c
            x = col * (cw + pad); y = row * (ch + pad)
            atlas.paste(img, (x, y))
        out = filedialog.asksaveasfilename(defaultextension=".png",
                                            filetypes=[("PNG", "*.png")],
                                            title="Save atlas as…")
        if not out:
            return
        atlas.save(out)
        log.info(f"Atlas saved: {out}")
        # Show in canvas as well
        self.state.image_path = Path(out)
        self.state.original = atlas.copy()
        self.state.image = atlas
        self.state.notify("image_loaded")


# ---------------------------------------------------------------------------
# Canvas with before/after slider
# ---------------------------------------------------------------------------

class Canvas(ctk.CTkFrame):
    def __init__(self, master, state: AppState):
        super().__init__(master, fg_color=Theme.BG, corner_radius=0)
        self.state = state
        self.state.listeners.append(self._on_state)
        self._ctk_img: ctk.CTkImage | None = None
        self.split = 1.0  # 1.0 = full after, 0.0 = full before

        self._inner = ctk.CTkFrame(self, fg_color=Theme.BG, corner_radius=0)
        self._inner.pack(fill="both", expand=True, padx=12, pady=12)

        self.empty_frame = ctk.CTkFrame(self._inner, fg_color="transparent")
        ctk.CTkLabel(
            self.empty_frame,
            text="No image loaded",
            text_color=Theme.TEXT_MUTED, font=(Theme.FONT, 14, "bold")
        ).pack(pady=(0, 6))
        ctk.CTkLabel(
            self.empty_frame,
            text=("Drop an image or folder anywhere, or open one below.\n"
                  + ("Drag-and-drop is active." if DND_AVAILABLE
                     else "(Drag-and-drop unavailable — pip install tkinterdnd2.)")),
            text_color=Theme.TEXT_DIM, font=(Theme.FONT, 11), justify="center"
        ).pack(pady=(0, 16))
        self.open_btn = ctk.CTkButton(
            self.empty_frame, text="Open image…", height=34, width=160,
            fg_color=Theme.ACCENT, hover_color=Theme.ACCENT_HI,
            text_color="#ffffff", font=(Theme.FONT, 12, "bold"),
            corner_radius=Theme.R_MD)
        self.open_btn.pack()
        self.empty_frame.pack(expand=True)

        self.image_holder = ctk.CTkLabel(self._inner, text="", fg_color=Theme.BG)

        self.slider_frame = ctk.CTkFrame(self, fg_color=Theme.SURFACE,
                                          corner_radius=0,
                                          border_width=1, border_color=Theme.BORDER)
        self.slider_lbl = ctk.CTkLabel(self.slider_frame, text="Before / After",
                                        text_color=Theme.TEXT_MUTED,
                                        font=(Theme.FONT, 10))
        self.slider_lbl.pack(side="left", padx=10)
        self.slider = ctk.CTkSlider(self.slider_frame, from_=0, to=1,
                                     number_of_steps=100,
                                     button_color=Theme.ACCENT,
                                     button_hover_color=Theme.ACCENT_HI,
                                     progress_color=Theme.ACCENT_LO,
                                     fg_color=Theme.BORDER,
                                     command=self._on_slider)
        self.slider.set(1.0)
        self.slider.pack(side="left", fill="x", expand=True, padx=(0, 10), pady=8)

    def _on_state(self, event):
        if self.state.image is None:
            self.image_holder.pack_forget()
            self.slider_frame.pack_forget()
            self.empty_frame.pack(expand=True)
            return
        self.empty_frame.pack_forget()
        self.image_holder.pack(expand=True)
        if self.state.last_preview is not None:
            self.slider_frame.pack(fill="x", side="bottom")
        self._render()

    def _on_slider(self, value):
        self.split = float(value)
        self._render()

    def _render(self):
        if self.state.image is None:
            return
        # Compute fit-to-canvas size
        self.update_idletasks()
        cw = max(200, self._inner.winfo_width() - 24)
        ch = max(200, self._inner.winfo_height() - 24)
        img = self.state.image
        before = self.state.last_preview
        w, h = img.size
        scale = min(cw / w, ch / h, 1.0)
        new_size = (max(1, int(w * scale)), max(1, int(h * scale)))
        disp = img.resize(new_size, Image.LANCZOS)

        if before is not None and self.split < 0.999:
            before_resized = before.resize(new_size, Image.LANCZOS) \
                if before.size != new_size else before
            if before_resized.mode != disp.mode:
                before_resized = before_resized.convert(disp.mode)
            split_x = int(new_size[0] * self.split)
            composite = before_resized.copy()
            composite.paste(disp.crop((0, 0, split_x, new_size[1])), (0, 0))
            # Draw a thin coral split line
            d = ImageDraw.Draw(composite)
            d.line([(split_x, 0), (split_x, new_size[1])],
                   fill=Theme.ACCENT, width=2)
            disp = composite

        self._ctk_img = ctk.CTkImage(light_image=disp, dark_image=disp,
                                      size=disp.size)
        self.image_holder.configure(image=self._ctk_img, text="")


# ---------------------------------------------------------------------------
# Top bar, left rail, status bar
# ---------------------------------------------------------------------------

class TopBar(ctk.CTkFrame):
    def __init__(self, master, app: "ImageUtilityApp"):
        super().__init__(master, fg_color=Theme.SURFACE, height=44,
                         corner_radius=0)
        self.app = app
        self.pack_propagate(False)

        left = ctk.CTkFrame(self, fg_color="transparent")
        left.pack(side="left", padx=12, pady=6, fill="y")
        ctk.CTkLabel(left, text="◐", text_color=Theme.ACCENT,
                     font=(Theme.FONT, 18, "bold")).pack(side="left", padx=(0, 8))
        ctk.CTkLabel(left, text="Image Utility", text_color=Theme.TEXT,
                     font=(Theme.FONT, 13, "bold")).pack(side="left")
        ctk.CTkLabel(left, text="v2", text_color=Theme.TEXT_DIM,
                     font=(Theme.FONT, 10)).pack(side="left", padx=(6, 0))

        right = ctk.CTkFrame(self, fg_color="transparent")
        right.pack(side="right", padx=12, pady=6, fill="y")

        self.queue_btn = ctk.CTkButton(
            right, text="  Queue · 0  ",
            command=self.app.show_queue, fg_color=Theme.ACCENT_SOFT,
            hover_color=Theme.ACCENT_LO, text_color=Theme.ACCENT_HI,
            border_color=Theme.ACCENT_LO, border_width=1,
            font=(Theme.FONT, 11, "bold"), height=28, corner_radius=Theme.R_SM)
        self.queue_btn.pack(side="right", padx=3)

        ctk.CTkButton(right, text="Presets ▾", command=self.app.show_presets,
                      fg_color="transparent", hover_color=Theme.SURFACE_2,
                      text_color=Theme.TEXT_MUTED, border_color=Theme.BORDER,
                      border_width=1, font=(Theme.FONT, 11), height=28,
                      corner_radius=Theme.R_SM).pack(side="right", padx=3)

        ctk.CTkButton(right, text="↷", command=self.app.redo,
                      width=32, height=28,
                      fg_color="transparent", hover_color=Theme.SURFACE_2,
                      text_color=Theme.TEXT_MUTED, border_color=Theme.BORDER,
                      border_width=1, font=(Theme.FONT, 14),
                      corner_radius=Theme.R_SM).pack(side="right", padx=3)
        ctk.CTkButton(right, text="↶", command=self.app.undo,
                      width=32, height=28,
                      fg_color="transparent", hover_color=Theme.SURFACE_2,
                      text_color=Theme.TEXT_MUTED, border_color=Theme.BORDER,
                      border_width=1, font=(Theme.FONT, 14),
                      corner_radius=Theme.R_SM).pack(side="right", padx=3)

        ctk.CTkButton(right, text="Open", command=self.app.open_image,
                      fg_color="transparent", hover_color=Theme.SURFACE_2,
                      text_color=Theme.TEXT, border_color=Theme.BORDER_HI,
                      border_width=1, font=(Theme.FONT, 11, "bold"),
                      height=28, corner_radius=Theme.R_SM).pack(side="right", padx=3)
        ctk.CTkButton(right, text="Save", command=self.app.save_image,
                      fg_color="transparent", hover_color=Theme.SURFACE_2,
                      text_color=Theme.TEXT, border_color=Theme.BORDER_HI,
                      border_width=1, font=(Theme.FONT, 11, "bold"),
                      height=28, corner_radius=Theme.R_SM).pack(side="right", padx=3)

    def update_queue_count(self, n: int):
        self.queue_btn.configure(text=f"  Queue · {n}  ")


class LeftRail(ctk.CTkFrame):
    def __init__(self, master, app: "ImageUtilityApp"):
        super().__init__(master, fg_color=Theme.SURFACE, width=64,
                         corner_radius=0)
        self.app = app
        self.pack_propagate(False)
        self.buttons: dict[str, ctk.CTkButton] = {}

        inner = ctk.CTkFrame(self, fg_color="transparent")
        inner.pack(fill="both", expand=True, padx=6, pady=10)

        for tool in app.tools.values():
            b = ctk.CTkButton(
                inner, text=tool.icon, width=52, height=44,
                font=(Theme.FONT, 18),
                fg_color="transparent", hover_color=Theme.SURFACE_2,
                text_color=Theme.TEXT_MUTED, corner_radius=Theme.R_SM,
                command=lambda t=tool.tool_id: app.activate_tool(t))
            b.pack(pady=2)
            self.buttons[tool.tool_id] = b

    def set_active(self, tool_id: str):
        for tid, b in self.buttons.items():
            if tid == tool_id:
                b.configure(fg_color=Theme.ACCENT_SOFT,
                            text_color=Theme.ACCENT_HI)
            else:
                b.configure(fg_color="transparent", text_color=Theme.TEXT_MUTED)


class StatusBar(ctk.CTkFrame):
    def __init__(self, master, app: "ImageUtilityApp"):
        super().__init__(master, fg_color=Theme.SURFACE, height=28,
                         corner_radius=0)
        self.app = app
        self.pack_propagate(False)
        self.expanded = False

        bar = ctk.CTkFrame(self, fg_color="transparent")
        bar.pack(fill="x")
        self.dot = ctk.CTkLabel(bar, text="●", text_color=Theme.SUCCESS,
                                 font=(Theme.FONT, 12))
        self.dot.pack(side="left", padx=(12, 6), pady=4)
        self.status = ctk.CTkLabel(bar, text="Ready",
                                    text_color=Theme.TEXT_MUTED,
                                    font=(Theme.FONT, 11))
        self.status.pack(side="left", pady=4)

        self.toggle_btn = ctk.CTkButton(
            bar, text="Logs ▴", command=self.toggle,
            fg_color="transparent", hover_color=Theme.SURFACE_2,
            text_color=Theme.TEXT_MUTED, font=(Theme.FONT, 11),
            width=70, height=20, corner_radius=Theme.R_SM)
        self.toggle_btn.pack(side="right", padx=8, pady=4)

        self.log_view = ctk.CTkTextbox(self, fg_color=Theme.BG,
                                        text_color=Theme.TEXT_MUTED,
                                        font=(Theme.FONT_MONO, 10),
                                        border_width=0, height=160)
        log.listeners.append(self._on_log)

    def _on_log(self, level: str, line: str):
        try:
            self.log_view.insert("end", line + "\n")
            self.log_view.see("end")
        except Exception:
            pass
        # Tint dot momentarily based on level
        color = {"INFO": Theme.SUCCESS, "WARNING": Theme.WARNING,
                 "ERROR": Theme.DANGER}.get(level, Theme.TEXT_MUTED)
        self.dot.configure(text_color=color)
        # Strip "[HH:MM:SS] LEVEL  " prefix so the status reads cleanly
        msg = line
        if line.startswith("[") and "] " in line:
            msg = line.split("] ", 1)[1]
            for lvl in ("INFO   ", "WARNING", "ERROR  ", "DEBUG  "):
                if msg.startswith(lvl):
                    msg = msg[len(lvl):].lstrip()
                    break
        self.status.configure(text=msg[:90])

    def toggle(self):
        self.expanded = not self.expanded
        if self.expanded:
            self.configure(height=190)
            self.log_view.pack(fill="both", expand=True, padx=8, pady=(0, 8))
            self.toggle_btn.configure(text="Logs ▾")
        else:
            self.log_view.pack_forget()
            self.configure(height=28)
            self.toggle_btn.configure(text="Logs ▴")


# ---------------------------------------------------------------------------
# Main app
# ---------------------------------------------------------------------------

# Pick the right root class — TkinterDnD's root if available, else plain CTk
if DND_AVAILABLE:
    class _Root(ctk.CTk, TkinterDnD.DnDWrapper):
        def __init__(self, *a, **kw):
            super().__init__(*a, **kw)
            self.TkdndVersion = TkinterDnD._require(self)
else:
    _Root = ctk.CTk


class ImageUtilityApp(_Root):
    def __init__(self):
        super().__init__()
        self.title("Image Utility")
        self.geometry("1200x780")
        self.minsize(900, 600)
        self.configure(fg_color=Theme.BG)

        self.app_state = AppState()
        self.app_state._tk_root = self   # marshal notify() to main thread
        log.tk_root = self                # same for logs
        self.app_state.load_presets()
        self.app_state.listeners.append(self._on_state)

        # Register tools
        self.tools: dict[str, Tool] = {}
        for cls in [BgRemovalTool, ResizeConvertTool, CropRotateTool,
                    ColorAdjustTool, WatermarkTool, BatchRenameTool,
                    GridSplitTool, AtlasCreatorTool]:
            tool = cls(self)
            self.tools[tool.tool_id] = tool

        self._build_layout()
        self.canvas.open_btn.configure(command=self.open_image)  # wire empty-state button
        self.activate_tool(self.app_state.active_tool)

        if DND_AVAILABLE:
            self.drop_target_register(DND_FILES)
            self.dnd_bind("<<Drop>>", self._on_drop)

        log.info("App started")
        if not DND_AVAILABLE:
            log.warn("tkinterdnd2 not installed — drag-and-drop disabled")

    # ---- layout ----

    def _build_layout(self):
        self.top = TopBar(self, self)
        self.top.pack(fill="x", side="top")
        sep = ctk.CTkFrame(self, fg_color=Theme.BORDER, height=1, corner_radius=0)
        sep.pack(fill="x", side="top")

        self.status_bar = StatusBar(self, self)
        self.status_bar.pack(fill="x", side="bottom")
        sep2 = ctk.CTkFrame(self, fg_color=Theme.BORDER, height=1, corner_radius=0)
        sep2.pack(fill="x", side="bottom")

        body = ctk.CTkFrame(self, fg_color=Theme.BG, corner_radius=0)
        body.pack(fill="both", expand=True)

        self.rail = LeftRail(body, self)
        self.rail.pack(side="left", fill="y")
        sep_v = ctk.CTkFrame(body, fg_color=Theme.BORDER, width=1, corner_radius=0)
        sep_v.pack(side="left", fill="y")

        self.canvas = Canvas(body, self.app_state)
        self.canvas.pack(side="left", fill="both", expand=True)

        sep_v2 = ctk.CTkFrame(body, fg_color=Theme.BORDER, width=1, corner_radius=0)
        sep_v2.pack(side="right", fill="y")
        self.panel_host = ctk.CTkFrame(body, fg_color=Theme.SURFACE,
                                        width=300, corner_radius=0)
        self.panel_host.pack(side="right", fill="y")
        self.panel_host.pack_propagate(False)

    # ---- tool switching ----

    def activate_tool(self, tool_id: str):
        if tool_id not in self.tools:
            return
        self.app_state.active_tool = tool_id
        self.rail.set_active(tool_id)
        # Clear and rebuild panel
        for child in self.panel_host.winfo_children():
            child.destroy()
        tool = self.tools[tool_id]

        # Header
        header = ctk.CTkFrame(self.panel_host, fg_color="transparent")
        header.pack(fill="x", padx=18, pady=(18, 4))
        ctk.CTkLabel(header, text=tool.name, text_color=Theme.TEXT,
                     font=(Theme.FONT, 14, "bold"),
                     anchor="w").pack(fill="x")
        if tool.description:
            ctk.CTkLabel(header, text=tool.description,
                         text_color=Theme.TEXT_DIM,
                         font=(Theme.FONT, 10), anchor="w").pack(fill="x")

        sep = ctk.CTkFrame(self.panel_host, fg_color=Theme.BORDER,
                            height=1, corner_radius=0)
        sep.pack(fill="x", padx=18, pady=10)

        body = ctk.CTkScrollableFrame(self.panel_host, fg_color="transparent",
                                       scrollbar_button_color=Theme.BORDER_HI,
                                       scrollbar_button_hover_color=Theme.ACCENT)
        body.pack(fill="both", expand=True, padx=18, pady=(0, 6))
        tool.build_panel(body)

        # Footer actions
        footer = ctk.CTkFrame(self.panel_host, fg_color="transparent")
        footer.pack(fill="x", padx=18, pady=(8, 18), side="bottom")
        if tool.supports_apply:
            primary_button(footer, "Apply",
                           command=lambda: self._apply(tool_id),
                           icon="▶").pack(fill="x", pady=(0, 6))
        row = ctk.CTkFrame(footer, fg_color="transparent")
        row.pack(fill="x")
        ghost_button(row, "+ Queue",
                     command=lambda: self._add_to_queue(tool_id)).pack(
            side="left", fill="x", expand=True, padx=(0, 3))
        ghost_button(row, "Save preset",
                     command=lambda: self._save_preset(tool_id)).pack(
            side="left", fill="x", expand=True, padx=(3, 0))

    def _apply(self, tool_id: str):
        tool = self.tools[tool_id]
        if not tool.can_run():
            messagebox.showwarning("No image", "Open an image first.")
            return

        # For slow ops, show a non-blocking busy overlay
        busy = None
        if tool.is_slow:
            busy = ctk.CTkToplevel(self)
            busy.title("Working")
            busy.geometry("280x90")
            busy.configure(fg_color=Theme.SURFACE)
            busy.transient(self); busy.resizable(False, False)
            ctk.CTkLabel(busy, text=f"Running {tool.name}…",
                         text_color=Theme.TEXT,
                         font=(Theme.FONT, 12)).pack(pady=(18, 6))
            bar = ctk.CTkProgressBar(busy, mode="indeterminate",
                                      fg_color=Theme.BORDER,
                                      progress_color=Theme.ACCENT)
            bar.pack(fill="x", padx=24, pady=(0, 18))
            bar.start()

        def worker():
            try:
                tool.run_single()
            except Exception as e:
                log.error(f"{tool.name}: {e}")
                traceback.print_exc()
            finally:
                if busy is not None:
                    self.after(0, busy.destroy)
        threading.Thread(target=worker, daemon=True).start()

    # ---- queue ----

    def _add_to_queue(self, tool_id: str):
        tool = self.tools[tool_id]
        item = QueueItem(tool_id=tool_id, tool_name=tool.name,
                         settings=tool.get_settings())
        self.app_state.queue.append(item)
        self.top.update_queue_count(len(self.app_state.queue))
        log.info(f"Queued: {tool.name}")

    def show_queue(self):
        win = ctk.CTkToplevel(self)
        win.title("Queue")
        win.geometry("520x460")
        win.configure(fg_color=Theme.BG)
        win.transient(self); win.grab_set()

        ctk.CTkLabel(win, text="Operation queue",
                     text_color=Theme.TEXT, font=(Theme.FONT, 14, "bold")
                     ).pack(anchor="w", padx=20, pady=(18, 4))
        ctk.CTkLabel(win, text="Runs each operation in order on every image "
                              "in the input folder.",
                     text_color=Theme.TEXT_DIM, font=(Theme.FONT, 11),
                     anchor="w", justify="left", wraplength=480
                     ).pack(anchor="w", padx=20, pady=(0, 12))

        list_frame = ctk.CTkScrollableFrame(win, fg_color=Theme.SURFACE,
                                             corner_radius=Theme.R_MD)
        list_frame.pack(fill="both", expand=True, padx=20, pady=(0, 12))

        def refresh():
            for c in list_frame.winfo_children():
                c.destroy()
            if not self.app_state.queue:
                ctk.CTkLabel(list_frame, text="Queue is empty.",
                             text_color=Theme.TEXT_DIM,
                             font=(Theme.FONT, 11)).pack(pady=24)
                return
            for i, item in enumerate(self.app_state.queue):
                row = ctk.CTkFrame(list_frame, fg_color=Theme.SURFACE_2,
                                    corner_radius=Theme.R_SM)
                row.pack(fill="x", padx=6, pady=3)
                ctk.CTkLabel(row, text=f"{i+1}.", text_color=Theme.TEXT_DIM,
                             font=(Theme.FONT, 11), width=28
                             ).pack(side="left", padx=(8, 0), pady=8)
                ctk.CTkLabel(row, text=item.display(),
                             text_color=Theme.TEXT,
                             font=(Theme.FONT, 11, "bold"), anchor="w"
                             ).pack(side="left", padx=8, pady=8, fill="x", expand=True)
                ctk.CTkButton(row, text="✕", width=28, height=24,
                              fg_color="transparent", hover_color=Theme.DANGER,
                              text_color=Theme.TEXT_DIM,
                              command=lambda idx=i: (self.app_state.queue.pop(idx),
                                                     refresh(),
                                                     self.top.update_queue_count(
                                                         len(self.app_state.queue)))
                              ).pack(side="right", padx=8, pady=6)
        refresh()

        btns = ctk.CTkFrame(win, fg_color="transparent")
        btns.pack(fill="x", padx=20, pady=(0, 18))
        ghost_button(btns, "Clear all",
                     command=lambda: (self.app_state.queue.clear(), refresh(),
                                      self.top.update_queue_count(0))).pack(
            side="left", fill="x", expand=True, padx=(0, 4))
        primary_button(btns, "Run on folder…",
                       command=lambda: self._run_queue(win)).pack(
            side="left", fill="x", expand=True, padx=(4, 0))

    def _run_queue(self, parent_window):
        if not self.app_state.queue:
            messagebox.showinfo("Queue", "Queue is empty.")
            return
        in_dir = filedialog.askdirectory(title="Pick input folder")
        if not in_dir:
            return
        out_dir = filedialog.askdirectory(title="Pick output folder")
        if not out_dir:
            return
        in_dir, out_dir = Path(in_dir), Path(out_dir)
        files = [p for p in in_dir.iterdir()
                 if p.suffix.lower() in SUPPORTED_EXTS]
        if not files:
            messagebox.showinfo("Queue", "No supported images in folder.")
            return

        progress = ctk.CTkToplevel(parent_window)
        progress.title("Running queue")
        progress.geometry("420x140")
        progress.configure(fg_color=Theme.BG)
        progress.transient(parent_window); progress.grab_set()
        lbl = ctk.CTkLabel(progress, text="Starting…",
                            text_color=Theme.TEXT, font=(Theme.FONT, 11))
        lbl.pack(pady=(24, 8))
        bar = ctk.CTkProgressBar(progress, fg_color=Theme.BORDER,
                                  progress_color=Theme.ACCENT)
        bar.set(0); bar.pack(fill="x", padx=24, pady=8)

        def worker():
            for i, f in enumerate(files):
                lbl.configure(text=f"{i+1}/{len(files)}  {f.name}")
                bar.set(i / len(files))
                try:
                    img = Image.open(f); img.load()
                    if img.mode not in ("RGB", "RGBA"):
                        img = img.convert("RGBA" if "A" in img.getbands() else "RGB")
                    # Determine final output extension + save kwargs by walking
                    # the queue *in order* — later tools override earlier ones.
                    chosen_ext: str | None = None
                    save_kwargs: dict = {}
                    for item in self.app_state.queue:
                        tool = self.tools[item.tool_id]
                        tool.apply_settings(item.settings)
                        ext = tool.output_extension()
                        if ext is not None:
                            chosen_ext = ext
                            save_kwargs = tool.output_save_kwargs()
                        # Temporarily swap state image
                        save = self.app_state.image, self.app_state.last_preview
                        self.app_state.image = img
                        self.app_state.last_preview = None
                        # Run synchronously; commit() will overwrite state.image
                        tool.run_single()
                        img = self.app_state.image
                        self.app_state.image, self.app_state.last_preview = save
                    out_name = (f.stem + chosen_ext) if chosen_ext else f.name
                    out_path = out_dir / out_name
                    if img.mode == "RGBA" and out_path.suffix.lower() in {".jpg", ".jpeg"}:
                        bg = Image.new("RGB", img.size, (255, 255, 255))
                        bg.paste(img, mask=img.split()[3])
                        img = bg
                    img.save(out_path, **save_kwargs)
                    log.info(f"Queue: processed {f.name} -> {out_name}")
                except Exception as e:
                    log.error(f"Queue failed on {f.name}: {e}")
            bar.set(1.0)
            lbl.configure(text=f"Done — {len(files)} images")
            time.sleep(0.7)
            progress.destroy()

        threading.Thread(target=worker, daemon=True).start()

    # ---- presets ----

    def _save_preset(self, tool_id: str):
        dialog = ctk.CTkInputDialog(text="Preset name:", title="Save preset")
        name = dialog.get_input()
        if not name:
            return
        tool = self.tools[tool_id]
        self.app_state.presets[name] = {"tool_id": tool_id,
                                     "settings": tool.get_settings()}
        self.app_state.save_presets()
        log.info(f"Saved preset: {name}")

    def show_presets(self):
        win = ctk.CTkToplevel(self)
        win.title("Presets")
        win.geometry("420x440")
        win.configure(fg_color=Theme.BG)
        win.transient(self); win.grab_set()

        ctk.CTkLabel(win, text="Saved presets",
                     text_color=Theme.TEXT, font=(Theme.FONT, 14, "bold")
                     ).pack(anchor="w", padx=20, pady=(18, 12))

        body = ctk.CTkScrollableFrame(win, fg_color=Theme.SURFACE,
                                       corner_radius=Theme.R_MD)
        body.pack(fill="both", expand=True, padx=20, pady=(0, 18))

        if not self.app_state.presets:
            ctk.CTkLabel(body, text="No presets yet. Tweak a tool and click "
                                    "“Save preset” at the bottom of its panel.",
                         text_color=Theme.TEXT_DIM, font=(Theme.FONT, 11),
                         wraplength=340).pack(pady=24, padx=12)
            return

        for name, data in self.app_state.presets.items():
            row = ctk.CTkFrame(body, fg_color=Theme.SURFACE_2,
                                corner_radius=Theme.R_SM)
            row.pack(fill="x", padx=6, pady=3)
            info = ctk.CTkFrame(row, fg_color="transparent")
            info.pack(side="left", padx=10, pady=8, fill="x", expand=True)
            ctk.CTkLabel(info, text=name, text_color=Theme.TEXT,
                         font=(Theme.FONT, 11, "bold"), anchor="w"
                         ).pack(anchor="w")
            tool_name = self.tools.get(data["tool_id"])
            ctk.CTkLabel(info, text=tool_name.name if tool_name else data["tool_id"],
                         text_color=Theme.TEXT_DIM, font=(Theme.FONT, 10),
                         anchor="w").pack(anchor="w")

            ctk.CTkButton(row, text="Apply", width=64, height=26,
                          fg_color=Theme.ACCENT, hover_color=Theme.ACCENT_HI,
                          text_color="#fff", font=(Theme.FONT, 10, "bold"),
                          corner_radius=Theme.R_SM,
                          command=lambda d=data: self._apply_preset(d, win)
                          ).pack(side="right", padx=4, pady=6)
            ctk.CTkButton(row, text="✕", width=28, height=26,
                          fg_color="transparent", hover_color=Theme.DANGER,
                          text_color=Theme.TEXT_DIM,
                          command=lambda n=name: self._delete_preset(n, win)
                          ).pack(side="right", padx=(2, 8), pady=6)

    def _apply_preset(self, data: dict, win):
        tool_id = data["tool_id"]
        if tool_id not in self.tools:
            return
        self.tools[tool_id].apply_settings(data["settings"])
        # Rebuild the panel so any sliders/inputs reflect the loaded values
        self.activate_tool(tool_id)
        win.destroy()
        log.info(f"Applied preset for {tool_id}")

    def _delete_preset(self, name: str, win):
        self.app_state.presets.pop(name, None)
        self.app_state.save_presets()
        win.destroy()
        self.show_presets()

    # ---- file IO ----

    def open_image(self):
        path = filedialog.askopenfilename(
            title="Open image",
            filetypes=[("Images", "*.png *.jpg *.jpeg *.webp *.bmp *.tif *.tiff")])
        if path:
            self.app_state.load_image(Path(path))

    def save_image(self):
        if self.app_state.image is None:
            messagebox.showinfo("Save", "Nothing to save.")
            return
        suggested = (self.app_state.image_path.stem + "_edit"
                     if self.app_state.image_path else "image")
        path = filedialog.asksaveasfilename(
            initialfile=suggested,
            defaultextension=".png",
            filetypes=[("PNG", "*.png"), ("JPG", "*.jpg"),
                       ("WEBP", "*.webp")])
        if not path:
            return
        img = self.app_state.image
        if img.mode == "RGBA" and Path(path).suffix.lower() in {".jpg", ".jpeg"}:
            bg = Image.new("RGB", img.size, (255, 255, 255))
            bg.paste(img, mask=img.split()[3])
            img = bg
        img.save(path)
        log.info(f"Saved: {path}")

    # ---- drag and drop ----

    def _on_drop(self, event):
        # Event data is a string with file paths in braces
        raw = event.data
        paths = self._parse_dnd_paths(raw)
        if not paths:
            return
        p = Path(paths[0])
        if p.is_dir():
            log.info(f"Folder dropped: {p}  (use Queue → Run on folder)")
            # Set as default for batch tools
            for t in self.tools.values():
                if hasattr(t, "input_dir"):
                    t.input_dir = p
        elif p.suffix.lower() in SUPPORTED_EXTS:
            self.app_state.load_image(p)
        else:
            log.warn(f"Unsupported drop: {p}")

    def _parse_dnd_paths(self, raw: str) -> list[str]:
        # tkinterdnd2 returns "{path with spaces} {another}" or "path1 path2"
        out: list[str] = []
        buf = ""
        in_brace = False
        for c in raw:
            if c == "{":
                in_brace = True; buf = ""
            elif c == "}":
                in_brace = False; out.append(buf); buf = ""
            elif c == " " and not in_brace:
                if buf: out.append(buf); buf = ""
            else:
                buf += c
        if buf: out.append(buf)
        return out

    # ---- undo/redo wired to top bar ----

    def undo(self):
        if self.app_state.undo():
            log.info("Undo")

    def redo(self):
        if self.app_state.redo():
            log.info("Redo")

    # ---- state changes ----

    def _on_state(self, event: str):
        if event == "image_loaded":
            name = self.app_state.image_path.name if self.app_state.image_path else "image"
            w, h = self.app_state.image.size
            log.info(f"Loaded {name}  ({w}x{h})")


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main():
    try:
        app = ImageUtilityApp()
        app.mainloop()
    except Exception:
        traceback.print_exc()
        input("\nPress Enter to close…")


if __name__ == "__main__":
    main()
